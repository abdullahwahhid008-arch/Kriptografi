# LAPORAN PROJECT 1 KRIPTOGRAFI
## Analisis dan Implementasi AES-256-GCM

* **Penyusun:** Abdullah Wahid
* **NIM:** 20240801382
* **Mata Kuliah:** Kriptografi
* **Dosen Pengampu:** Ir. Nizirwan Anwar, MT, IPM, ASEAN.Eng., APEC Eng.
* **Universitas:** Universitas Esa Unggul (2026)

---

### ABSTRAK
Keamanan informasi menjadi kebutuhan utama ketika data disimpan dan dikirim melalui sistem komputer dan jaringan...
