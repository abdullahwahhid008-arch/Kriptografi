"""aesgcm_lab
Modul praktikum AES-256-GCM (Project 1 Kriptografi).
Penyusun: Abdullah Wahid (20240801382)
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

KEY_LEN = 32        # 256 bit
NONCE_LEN = 12      # 96 bit
TAG_LEN = 16        # 128 bit
MAGIC = b"VGCM1"
BLOCK = 16

class ContainerError(ValueError):
    """Berkas terenkripsi rusak atau format tidak dikenal."""

@dataclass(frozen=True)
class Sealed:
    nonce: bytes
    ciphertext: bytes
    tag: bytes

def new_key() -> bytes:
    return AESGCM.generate_key(bit_length=KEY_LEN * 8)

def new_nonce() -> bytes:
    return os.urandom(NONCE_LEN)

def seal(key: bytes, data: bytes, aad: bytes = b"", nonce: bytes | None = None) -> Sealed:
    nonce = new_nonce() if nonce is None else nonce
    if len(nonce) != NONCE_LEN:
        raise ValueError(f"Nonce harus {NONCE_LEN} byte.")
    out = AESGCM(key).encrypt(nonce, data, aad or None)
    return Sealed(nonce, out[:-TAG_LEN], out[-TAG_LEN:])

def unseal(key: bytes, sealed: Sealed, aad: bytes = b"") -> bytes:
    if len(sealed.nonce) != NONCE_LEN:
        raise ValueError(f"Nonce harus {NONCE_LEN} byte.")
    if len(sealed.tag) != TAG_LEN:
        raise ValueError(f"Tag harus {TAG_LEN} byte.")
    return AESGCM(key).decrypt(sealed.nonce, sealed.ciphertext + sealed.tag, aad or None)

def seal_text(key: bytes, text: str, aad: bytes = b"") -> Sealed:
    return seal(key, text.encode("utf-8"), aad)

def unseal_text(key: bytes, sealed: Sealed, aad: bytes = b"") -> str:
    return unseal(key, sealed, aad).decode("utf-8")

def encrypt_file(src: Path, dst: Path, key: bytes) -> int:
    s = seal(key, Path(src).read_bytes(), aad=MAGIC)
    blob = MAGIC + s.nonce + s.ciphertext + s.tag
    Path(dst).write_bytes(blob)
    return len(blob)

def decrypt_file(src: Path, dst: Path, key: bytes) -> int:
    blob = Path(src).read_bytes()
    if len(blob) < len(MAGIC) + NONCE_LEN + TAG_LEN:
        raise ContainerError("Berkas terlalu pendek.")
    if blob[: len(MAGIC)] != MAGIC:
        raise ContainerError("Penanda format tidak dikenali.")
    body = blob[len(MAGIC):]
    sealed = Sealed(body[:NONCE_LEN], body[NONCE_LEN:-TAG_LEN], body[-TAG_LEN:])
    plain = unseal(key, sealed, aad=MAGIC)
    Path(dst).write_bytes(plain)
    return len(plain)

def ecb_encrypt_for_demo(key: bytes, data: bytes) -> bytes:
    if len(data) % BLOCK:
        raise ValueError("Data demo harus kelipatan 16 byte.")
    enc = Cipher(algorithms.AES(key), modes.ECB()).encryptor()
    return enc.update(data) + enc.finalize()

def split_blocks(data: bytes) -> list[bytes]:
    return [data[i:i + BLOCK] for i in range(0, len(data), BLOCK)]

def count_repeated_blocks(data: bytes) -> int:
    blocks = split_blocks(data)
    return len(blocks) - len(set(blocks))
