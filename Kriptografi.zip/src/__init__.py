"""Paket kueri kriptografi AES-GCM."""
