"""Antarmuka CLI AES-256-GCM.
Penyusun: Abdullah Wahid (20240801382)
"""
from __future__ import annotations

import argparse
import hashlib
import os
import sys
from pathlib import Path

from cryptography.exceptions import InvalidTag
import src.aesgcm_lab as lab

PLAINTEXT = "ABDULLAH WAHID - PROJECT 1 KRIPTOGRAFI"
AAD_DEMO = b"kriptografi-project1"
LINE = "-" * 66

def hx(b: bytes) -> str:
    return b.hex().upper()

def cmd_demo(_: argparse.Namespace) -> int:
    key = lab.new_key()
    print("=" * 66)
    print(" AES-256-GCM | Praktikum Kriptografi | Abdullah Wahid")
    print("=" * 66)
    print(f"Plaintext      : {PLAINTEXT}")
    print(f"Plaintext (hex): {hx(PLAINTEXT.encode())}")
    print(f"Kunci          : {len(key)*8} bit (tersembunyi)")
    print(f"AAD            : {AAD_DEMO.decode()}")
    
    s = lab.seal_text(key, PLAINTEXT, AAD_DEMO)
    print(LINE)
    print(f"Nonce          : {hx(s.nonce)}")
    print(f"Ciphertext     : {hx(s.ciphertext)}")
    print(f"Tag            : {hx(s.tag)}")
    print(LINE)
    
    back = lab.unseal_text(key, s, AAD_DEMO)
    print(f"Hasil dekripsi : {back}")
    ok = back == PLAINTEXT
    print(f"Verifikasi     : {'COCOK - SUKSES' if ok else 'GAGAL'}")
    
    try:
        lab.unseal_text(key, s, b"aad-salah")
    except InvalidTag:
        print("Uji AAD salah  : DITOLAK (InvalidTag)")
    return 0 if ok else 1

def cmd_keygen(a: argparse.Namespace) -> int:
    out = Path(a.out)
    if out.exists():
        print(f"File {out} sudah ada.", file=sys.stderr)
        return 1
    out.write_text(lab.new_key().hex())
    print(f"Kunci 256 bit disimpan ke {out}.")
    return 0

def load_key(path: str) -> bytes:
    return bytes.fromhex(Path(path).read_text().strip())

def cmd_encrypt(a: argparse.Namespace) -> int:
    n = lab.encrypt_file(Path(a.infile), Path(a.out), load_key(a.key))
    print(f"Terenkripsi: {a.infile} -> {a.out} ({n} byte)")
    return 0

def cmd_decrypt(a: argparse.Namespace) -> int:
    try:
        n = lab.decrypt_file(Path(a.infile), Path(a.out), load_key(a.key))
    except InvalidTag:
        print("GAGAL: Tag tidak valid.", file=sys.stderr)
        return 2
    print(f"Terdekripsi: {a.infile} -> {a.out} ({n} byte)")
    return 0

def cmd_ecb(_: argparse.Namespace) -> int:
    key = lab.new_key()
    data = b"BLOK-UJI-AES-128" * 4
    ecb = lab.ecb_encrypt_for_demo(key, data)
    s = lab.seal(key, data)
    print("ECB berulang:", lab.count_repeated_blocks(ecb))
    print("GCM berulang:", lab.count_repeated_blocks(s.ciphertext))
    return 0

def cmd_filedemo(_: argparse.Namespace) -> int:
    import tempfile
    key = lab.new_key()
    with tempfile.TemporaryDirectory() as d:
        d = Path(d)
        src, enc, dec = d / "catatan.txt", d / "catatan.vgcm", d / "hasil.txt"
        src.write_text("Catatan uji enkripsi berkas.\n")
        lab.encrypt_file(src, enc, key)
        lab.decrypt_file(enc, dec, key)
        print("File demo berhasil dienkripsi dan didekripsi kembali.")
    return 0

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="python -m src.cli")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("demo").set_defaults(fn=cmd_demo)
    k = sub.add_parser("keygen")
    k.add_argument("--out", required=True)
    k.set_defaults(fn=cmd_keygen)
    for name, fn in (("encrypt-file", cmd_encrypt), ("decrypt-file", cmd_decrypt)):
        e = sub.add_parser(name)
        e.add_argument("--key", required=True)
        e.add_argument("--in", dest="infile", required=True)
        e.add_argument("--out", required=True)
        e.set_defaults(fn=fn)
    sub.add_parser("ecb-demo").set_defaults(fn=cmd_ecb)
    sub.add_parser("file-demo").set_defaults(fn=cmd_filedemo)
    return p

def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.fn(args)

if __name__ == "__main__":
    raise SystemExit(main())
