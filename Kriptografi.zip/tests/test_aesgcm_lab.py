import tempfile
import unittest
from pathlib import Path
from cryptography.exceptions import InvalidTag
import src.aesgcm_lab as lab

class TestAESGCM(unittest.TestCase):
    def test_roundtrip(self):
        key = lab.new_key()
        s = lab.seal_text(key, "Halo Dunia", b"aad")
        self.assertEqual(lab.unseal_text(key, s, b"aad"), "Halo Dunia")

    def test_wrong_tag(self):
        key = lab.new_key()
        s = lab.seal_text(key, "Halo Dunia")
        bad = lab.Sealed(s.nonce, s.ciphertext, bytearray(s.tag))
        with self.assertRaises(InvalidTag):
            lab.unseal(key, bad)

if __name__ == "__main__":
    unittest.main()
