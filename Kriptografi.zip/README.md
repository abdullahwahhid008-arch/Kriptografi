# Kriptografi AES-GCM

Repositori ini berisi implementasi dan laporan praktikum **Project 1 Kriptografi** mengenai analisis dan penerapan algoritma enkripsi simetris **Advanced Encryption Standard (AES)** mode **Galois/Counter Mode (GCM)** menggunakan bahasa pemrograman Python.

## 👤 Identitas Penyusun
* **Nama:** Abdullah Wahid
* **NIM:** 20240801382
* **Mata Kuliah:** Kriptografi
* **Dosen Pengampu:** Ir. Nizirwan Anwar, MT, IPM, ASEAN.Eng., APEC Eng.
* **Universitas:** Universitas Esa Unggul

---

## 📂 Struktur Repositori
```text
Kriptografi/
├── Docs/
│   └── Laporan_Kriptografi_AES_Abdullah_Wahid.pdf
├── src/
│   ├── __init__.py
│   ├── aesgcm_lab.py
│   └── cli.py
├── tests/
│   └── test_aesgcm_lab.py
├── .gitignore
├── requirements.txt
└── README.md
```

---

## 🚀 Cara Menjalankan

1. **Clone repositori ini:**
   ```bash
   git clone https://github.com/VeeCaprio/Kriptografi.git
   cd Kriptografi
   ```

2. **Buat dan aktifkan virtual environment:**
   ```bash
   python -m venv .venv
   # Windows PowerShell:
   .venv\Scripts\Activate.ps1
   # Linux / macOS:
   # source .venv/bin/activate
   ```

3. **Install dependensi:**
   ```bash
   python -m pip install -r requirements.txt
   ```

4. **Jalankan demo program:**
   * Demo Enkripsi Teks & AAD:
     ```bash
     python -m src.cli demo
     ```
   * Demo Perbandingan ECB dan GCM:
     ```bash
     python -m src.cli ecb-demo
     ```
   * Demo Enkripsi Berkas:
     ```bash
     python -m src.cli file-demo
     ```

5. **Jalankan Unit Testing (17 Unit Test):**
   ```bash
   python -m unittest discover -s tests -v
   ```
