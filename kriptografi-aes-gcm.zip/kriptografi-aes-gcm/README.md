# Kriptografi AES-256-GCM (Project 1)

Project mata kuliah Kriptografi - Universitas Esa Unggul.
Penyusun: **Vramudhia Egy Pratama** ([@VeeCaprio](https://github.com/VeeCaprio))

Praktikum enkripsi dan dekripsi **AES-256 mode GCM** dengan Python memakai pustaka
[`cryptography`](https://cryptography.io). Seluruh operasi kriptografi dikerjakan
pustaka; kode di sini hanya membungkus dan mengujinya. Data yang dipakai hanya data uji.

## Fitur

- Enkripsi/dekripsi teks dengan nonce acak 96 bit dan authentication tag 128 bit
- Dukungan AAD (data tambahan yang ikut diautentikasi)
- Enkripsi berkas dengan format wadah `VGCM1 | nonce | ciphertext | tag`
- Demonstrasi pola yang bocor pada ECB dibanding GCM
- 17 unit test, termasuk vektor uji resmi FIPS 197 dan GCM

## Struktur

```
kriptografi-aes-gcm/
├── src/
│   ├── aesgcm_lab.py     # fungsi seal/unseal, enkripsi berkas, demo ECB
│   └── cli.py            # antarmuka baris perintah
├── tests/test_aesgcm_lab.py
├── screenshots/
├── requirements.txt
└── README.md
```

## Cara menjalankan

```bash
git clone https://github.com/VeeCaprio/kriptografi-aes-gcm.git
cd kriptografi-aes-gcm

python -m venv .venv
# Windows PowerShell : .venv\Scripts\Activate.ps1
# Linux / macOS      : source .venv/bin/activate

python -m pip install -r requirements.txt

python -m src.cli demo          # demo enkripsi teks + AAD
python -m src.cli ecb-demo      # ECB vs GCM
python -m src.cli file-demo     # demo enkripsi berkas

python -m unittest discover -s tests -v
```

Enkripsi berkas sendiri:

```bash
python -m src.cli keygen --out rahasia.key
python -m src.cli encrypt-file --key rahasia.key --in catatan.txt --out catatan.vgcm
python -m src.cli decrypt-file --key rahasia.key --in catatan.vgcm --out hasil.txt
```

## Catatan keamanan

- Berkas `*.key` dan `*.vgcm` sudah masuk `.gitignore`; jangan pernah meng-commit kunci.
- Nonce dibuat acak untuk setiap enkripsi dan tidak boleh dipakai ulang pada kunci yang sama.
- Mode ECB hanya ada untuk demonstrasi, jangan dipakai untuk data nyata.
- Proyek ini untuk pembelajaran, bukan sistem produksi.
