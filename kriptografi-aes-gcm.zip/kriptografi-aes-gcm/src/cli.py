"""Antarmuka baris perintah praktikum AES-256-GCM.

Contoh:
    python -m src.cli demo
    python -m src.cli keygen --out rahasia.key
    python -m src.cli encrypt-file --key rahasia.key --in catatan.txt --out catatan.vgcm
    python -m src.cli decrypt-file --key rahasia.key --in catatan.vgcm --out hasil.txt
    python -m src.cli ecb-demo
"""

from __future__ import annotations

import argparse
import hashlib
import os
import sys
from pathlib import Path

from cryptography.exceptions import InvalidTag

from . import aesgcm_lab as lab

PLAINTEXT = "VRAMUDHIA EGY PRATAMA - PROJECT 1 KRIPTOGRAFI"
AAD_DEMO = b"kriptografi-project1"
LINE = "-" * 66


def hx(b: bytes) -> str:
    return b.hex().upper()


def cmd_demo(_: argparse.Namespace) -> int:
    key = lab.new_key()
    print("=" * 66)
    print(" AES-256-GCM  |  Praktikum Kriptografi  |  Vramudhia Egy Pratama")
    print("=" * 66)
    print(f"Plaintext        : {PLAINTEXT}")
    print(f"Plaintext (hex)  : {hx(PLAINTEXT.encode())}")
    print(f"Kunci            : {len(key) * 8} bit (nilai tidak ditampilkan)")
    print(f"AAD              : {AAD_DEMO.decode()}")
    s = lab.seal_text(key, PLAINTEXT, AAD_DEMO)
    print(LINE)
    print(f"Nonce            : {hx(s.nonce)}")
    print(f"Ciphertext       : {hx(s.ciphertext)}")
    print(f"Tag              : {hx(s.tag)}")
    print(LINE)
    back = lab.unseal_text(key, s, AAD_DEMO)
    print(f"Hasil dekripsi   : {back}")
    ok = back == PLAINTEXT
    print(f"Verifikasi       : {'COCOK - SUKSES' if ok else 'TIDAK COCOK - GAGAL'}")
    try:
        lab.unseal_text(key, s, b"aad-yang-salah")
    except InvalidTag:
        print("Uji AAD salah    : DITOLAK (InvalidTag)")
    return 0 if ok else 1


def cmd_keygen(a: argparse.Namespace) -> int:
    out = Path(a.out)
    if out.exists():
        print(f"Menolak menimpa {out}.", file=sys.stderr)
        return 1
    out.write_text(lab.new_key().hex())
    try:
        os.chmod(out, 0o600)
    except OSError:
        pass
    print(f"Kunci 256 bit ditulis ke {out}. Jangan commit/bagikan berkas ini.")
    return 0


def load_key(path: str) -> bytes:
    key = bytes.fromhex(Path(path).read_text().strip())
    if len(key) != lab.KEY_LEN:
        raise SystemExit("Panjang kunci harus 32 byte (64 karakter hex).")
    return key


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16].upper()


def cmd_encrypt(a: argparse.Namespace) -> int:
    n = lab.encrypt_file(Path(a.infile), Path(a.out), load_key(a.key))
    print(f"Terenkripsi : {a.infile} -> {a.out} ({n} byte)")
    return 0


def cmd_decrypt(a: argparse.Namespace) -> int:
    try:
        n = lab.decrypt_file(Path(a.infile), Path(a.out), load_key(a.key))
    except InvalidTag:
        print("GAGAL: tag tidak valid (kunci salah atau berkas diubah).", file=sys.stderr)
        return 2
    except lab.ContainerError as e:
        print(f"GAGAL: {e}", file=sys.stderr)
        return 3
    print(f"Terdekripsi : {a.infile} -> {a.out} ({n} byte)")
    return 0


def cmd_ecb(_: argparse.Namespace) -> int:
    key = lab.new_key()
    data = b"BLOK-UJI-AES-128" * 4              # empat blok 16 byte yang identik
    ecb = lab.ecb_encrypt_for_demo(key, data)
    s = lab.seal(key, data)
    print("Plaintext : 4 blok identik (16 byte x 4)")
    print(LINE)
    print("ECB  (jangan dipakai):")
    for i, b in enumerate(lab.split_blocks(ecb), 1):
        print(f"  blok {i}: {hx(b)}")
    print(f"  blok berulang : {lab.count_repeated_blocks(ecb)}  -> pola plaintext terlihat")
    print("GCM:")
    for i, b in enumerate(lab.split_blocks(s.ciphertext), 1):
        print(f"  blok {i}: {hx(b)}")
    print(f"  blok berulang : {lab.count_repeated_blocks(s.ciphertext)}  -> pola tersamarkan")
    return 0


def cmd_filedemo(_: argparse.Namespace) -> int:
    import tempfile
    key = lab.new_key()
    with tempfile.TemporaryDirectory() as d:
        d = Path(d)
        src, enc, dec = d / "catatan.txt", d / "catatan.vgcm", d / "hasil.txt"
        src.write_text("Catatan uji untuk enkripsi berkas.\n" * 20)
        lab.encrypt_file(src, enc, key)
        lab.decrypt_file(enc, dec, key)
        blob = enc.read_bytes()
        print(f"Berkas asli      : {src.stat().st_size} byte  SHA-256[:16]={sha(src)}")
        print(f"Berkas terenkrip : {enc.stat().st_size} byte  (= asli + 5 + 12 + 16)")
        print(f"Header (hex)     : {hx(blob[:5])} | nonce {hx(blob[5:17])}")
        print(f"Hasil dekripsi   : {dec.stat().st_size} byte  SHA-256[:16]={sha(dec)}")
        print(f"Hash sama        : {sha(src) == sha(dec)}")
        bad = bytearray(blob); bad[20] ^= 0x01
        enc.write_bytes(bytes(bad))
        try:
            lab.decrypt_file(enc, dec, key)
        except InvalidTag:
            print("Berkas diubah 1 bit -> DITOLAK (InvalidTag), tidak ada keluaran ditulis")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="python -m src.cli", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("demo", help="demo enkripsi teks + AAD").set_defaults(fn=cmd_demo)
    k = sub.add_parser("keygen", help="buat berkas kunci 256 bit"); k.add_argument("--out", required=True); k.set_defaults(fn=cmd_keygen)
    for name, fn in (("encrypt-file", cmd_encrypt), ("decrypt-file", cmd_decrypt)):
        e = sub.add_parser(name)
        e.add_argument("--key", required=True); e.add_argument("--in", dest="infile", required=True); e.add_argument("--out", required=True)
        e.set_defaults(fn=fn)
    sub.add_parser("ecb-demo", help="bandingkan ECB dan GCM").set_defaults(fn=cmd_ecb)
    sub.add_parser("file-demo", help="demo enkripsi berkas sementara").set_defaults(fn=cmd_filedemo)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    raise SystemExit(main())
