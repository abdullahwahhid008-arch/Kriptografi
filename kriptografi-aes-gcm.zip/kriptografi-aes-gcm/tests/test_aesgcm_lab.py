import tempfile
import unittest
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from src import aesgcm_lab as lab

TEKS = "VRAMUDHIA EGY PRATAMA - PROJECT 1 KRIPTOGRAFI"


def flip(b: bytes, i: int = 0) -> bytes:
    x = bytearray(b)
    x[i] ^= 0x01
    return bytes(x)


class KnownAnswerTests(unittest.TestCase):
    """Vektor uji resmi, agar kebenaran pustaka dan parameter terverifikasi."""

    def test_fips197_c3_aes256_block(self):
        key = bytes(range(32))
        pt = bytes.fromhex("00112233445566778899aabbccddeeff")
        enc = Cipher(algorithms.AES(key), modes.ECB()).encryptor()
        self.assertEqual((enc.update(pt) + enc.finalize()).hex(),
                         "8ea2b7ca516745bfeafc49904b496089")

    def test_gcm_aes256_zero_key_empty_plaintext(self):
        s = lab.seal(bytes(32), b"", nonce=bytes(12))
        self.assertEqual(s.ciphertext, b"")
        self.assertEqual(s.tag.hex(), "530f8afbc74536b9a963b4f1c4cb738b")

    def test_gcm_aes256_zero_key_one_zero_block(self):
        s = lab.seal(bytes(32), bytes(16), nonce=bytes(12))
        self.assertEqual(s.ciphertext.hex(), "cea7403d4d606b6e074ec5d3baf39d18")
        self.assertEqual(s.tag.hex(), "d0d1c8a799996bf0265b98b5d48ab919")


class RoundTripAndTamper(unittest.TestCase):
    def setUp(self):
        self.key = lab.new_key()
        self.aad = b"header-uji"
        self.s = lab.seal_text(self.key, TEKS, self.aad)

    def test_roundtrip_text(self):
        self.assertEqual(lab.unseal_text(self.key, self.s, self.aad), TEKS)

    def test_ciphertext_same_length_as_plaintext(self):
        self.assertEqual(len(self.s.ciphertext), len(TEKS.encode()))

    def test_flip_every_ciphertext_byte_is_rejected(self):
        for i in range(len(self.s.ciphertext)):
            bad = lab.Sealed(self.s.nonce, flip(self.s.ciphertext, i), self.s.tag)
            with self.assertRaises(InvalidTag, msg=f"byte {i}"):
                lab.unseal(self.key, bad, self.aad)

    def test_flip_every_tag_byte_is_rejected(self):
        for i in range(lab.TAG_LEN):
            bad = lab.Sealed(self.s.nonce, self.s.ciphertext, flip(self.s.tag, i))
            with self.assertRaises(InvalidTag):
                lab.unseal(self.key, bad, self.aad)

    def test_wrong_key(self):
        with self.assertRaises(InvalidTag):
            lab.unseal(lab.new_key(), self.s, self.aad)

    def test_wrong_nonce(self):
        bad = lab.Sealed(flip(self.s.nonce), self.s.ciphertext, self.s.tag)
        with self.assertRaises(InvalidTag):
            lab.unseal(self.key, bad, self.aad)

    def test_wrong_aad(self):
        with self.assertRaises(InvalidTag):
            lab.unseal(self.key, self.s, b"aad-lain")

    def test_bad_lengths(self):
        with self.assertRaises(ValueError):
            lab.seal(self.key, b"x", nonce=b"pendek")
        with self.assertRaises(ValueError):
            lab.unseal(self.key, lab.Sealed(self.s.nonce, self.s.ciphertext, b"x"))

    def test_nonces_do_not_repeat_in_10000_draws(self):
        self.assertEqual(len({lab.new_nonce() for _ in range(10000)}), 10000)

    def test_same_plaintext_gives_different_ciphertext(self):
        a = lab.seal_text(self.key, TEKS)
        b = lab.seal_text(self.key, TEKS)
        self.assertNotEqual(a.ciphertext, b.ciphertext)


class FileContainer(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.d = Path(self.tmp.name)
        self.key = lab.new_key()
        self.src = self.d / "a.bin"
        self.src.write_bytes(bytes(range(256)) * 10)
        self.enc = self.d / "a.vgcm"
        self.out = self.d / "b.bin"

    def tearDown(self):
        self.tmp.cleanup()

    def test_file_roundtrip(self):
        n = lab.encrypt_file(self.src, self.enc, self.key)
        self.assertEqual(n, 2560 + len(lab.MAGIC) + lab.NONCE_LEN + lab.TAG_LEN)
        lab.decrypt_file(self.enc, self.out, self.key)
        self.assertEqual(self.out.read_bytes(), self.src.read_bytes())

    def test_modified_file_is_rejected_and_nothing_written(self):
        lab.encrypt_file(self.src, self.enc, self.key)
        self.enc.write_bytes(flip(self.enc.read_bytes(), 30))
        with self.assertRaises(InvalidTag):
            lab.decrypt_file(self.enc, self.out, self.key)
        self.assertFalse(self.out.exists())

    def test_truncated_and_wrong_magic(self):
        self.enc.write_bytes(b"VGCM1abc")
        with self.assertRaises(lab.ContainerError):
            lab.decrypt_file(self.enc, self.out, self.key)
        self.enc.write_bytes(b"XXXXX" + bytes(40))
        with self.assertRaises(lab.ContainerError):
            lab.decrypt_file(self.enc, self.out, self.key)


class EcbDemo(unittest.TestCase):
    def test_ecb_leaks_repetition_but_gcm_does_not(self):
        key = lab.new_key()
        data = b"0123456789ABCDEF" * 4
        self.assertEqual(lab.count_repeated_blocks(lab.ecb_encrypt_for_demo(key, data)), 3)
        self.assertEqual(lab.count_repeated_blocks(lab.seal(key, data).ciphertext), 0)


if __name__ == "__main__":
    unittest.main()
