"""aesgcm_lab - modul praktikum AES-256-GCM (Project 1 Kriptografi).

Penyusun: ABDULLAH WAHID

Seluruh operasi kriptografi dikerjakan oleh pustaka `cryptography`.
Modul ini hanya membungkusnya menjadi antarmuka yang lebih mudah diuji:
enkripsi teks/byte, enkripsi berkas dengan format wadah sederhana, serta
fungsi demonstrasi risiko mode ECB. Hanya untuk pembelajaran.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

KEY_LEN = 32            # byte -> AES-256
NONCE_LEN = 12          # byte -> 96 bit (rekomendasi NIST SP 800-38D)
TAG_LEN = 16            # byte -> 128 bit
MAGIC = b"VGCM1"        # penanda format berkas terenkripsi (juga dipakai sebagai AAD)
BLOCK = 16


class ContainerError(ValueError):
    """Berkas terenkripsi rusak, terpotong, atau bukan format yang dikenal."""


@dataclass(frozen=True)
class Sealed:
    """Hasil enkripsi GCM yang dipisah menjadi tiga komponen."""
    nonce: bytes
    ciphertext: bytes
    tag: bytes


def new_key() -> bytes:
    return AESGCM.generate_key(bit_length=KEY_LEN * 8)


def new_nonce() -> bytes:
    return os.urandom(NONCE_LEN)


def seal(key: bytes, data: bytes, aad: bytes = b"", nonce: bytes | None = None) -> Sealed:
    """Enkripsi `data`. Nonce acak baru dibuat bila tidak diberikan."""
    nonce = new_nonce() if nonce is None else nonce
    if len(nonce) != NONCE_LEN:
        raise ValueError(f"Nonce harus {NONCE_LEN} byte.")
    out = AESGCM(key).encrypt(nonce, data, aad or None)
    return Sealed(nonce, out[:-TAG_LEN], out[-TAG_LEN:])


def unseal(key: bytes, sealed: Sealed, aad: bytes = b"") -> bytes:
    """Verifikasi tag lalu dekripsi. Melempar InvalidTag bila autentikasi gagal."""
    if len(sealed.nonce) != NONCE_LEN:
        raise ValueError(f"Nonce harus {NONCE_LEN} byte.")
    if len(sealed.tag) != TAG_LEN:
        raise ValueError(f"Tag harus {TAG_LEN} byte.")
    return AESGCM(key).decrypt(sealed.nonce, sealed.ciphertext + sealed.tag, aad or None)


def seal_text(key: bytes, text: str, aad: bytes = b"") -> Sealed:
    return seal(key, text.encode("utf-8"), aad)


def unseal_text(key: bytes, sealed: Sealed, aad: bytes = b"") -> str:
    return unseal(key, sealed, aad).decode("utf-8")


# ---------- enkripsi berkas ----------
# Format: MAGIC (5) | nonce (12) | ciphertext (n) | tag (16)
def encrypt_file(src: Path, dst: Path, key: bytes) -> int:
    s = seal(key, Path(src).read_bytes(), aad=MAGIC)
    blob = MAGIC + s.nonce + s.ciphertext + s.tag
    Path(dst).write_bytes(blob)
    return len(blob)


def decrypt_file(src: Path, dst: Path, key: bytes) -> int:
    blob = Path(src).read_bytes()
    if len(blob) < len(MAGIC) + NONCE_LEN + TAG_LEN:
        raise ContainerError("Berkas terlalu pendek untuk format VGCM1.")
    if blob[: len(MAGIC)] != MAGIC:
        raise ContainerError("Penanda format tidak dikenali.")
    body = blob[len(MAGIC):]
    sealed = Sealed(body[:NONCE_LEN], body[NONCE_LEN:-TAG_LEN], body[-TAG_LEN:])
    plain = unseal(key, sealed, aad=MAGIC)      # tulis ke disk hanya jika tag valid
    Path(dst).write_bytes(plain)
    return len(plain)


# ---------- demonstrasi ECB (hanya untuk laporan) ----------
def ecb_encrypt_for_demo(key: bytes, data: bytes) -> bytes:
    """JANGAN dipakai untuk data nyata. Dipakai hanya untuk memperlihatkan pola ECB."""
    if len(data) % BLOCK:
        raise ValueError("Data demo harus kelipatan 16 byte.")
    enc = Cipher(algorithms.AES(key), modes.ECB()).encryptor()
    return enc.update(data) + enc.finalize()


def split_blocks(data: bytes) -> list[bytes]:
    return [data[i:i + BLOCK] for i in range(0, len(data), BLOCK)]


def count_repeated_blocks(data: bytes) -> int:
    blocks = split_blocks(data)
    return len(blocks) - len(set(blocks))
