# Praktikum Kriptografi AES-256-GCM

Proyek pembelajaran mata kuliah Kriptografi yang mendemonstrasikan enkripsi dan
dekripsi AES-256-GCM menggunakan Python dan pustaka
[`cryptography`](https://cryptography.io).

**Penyusun:** [Abdullah Wahid](https://github.com/abdullahwahhid008-arch)  
**GitHub:** [@abdullahwahhid008-arch](https://github.com/abdullahwahhid008-arch)

Proyek ini menggunakan data uji dan ditujukan untuk pembelajaran. Operasi
kriptografi ditangani oleh pustaka `cryptography`.

## Fitur

- Enkripsi dan dekripsi teks maupun byte dengan AES-256-GCM
- Nonce acak 96 bit dan authentication tag 128 bit
- Dukungan AAD (*Additional Authenticated Data*)
- Enkripsi berkas dengan format `VGCM1 | nonce | ciphertext | tag`
- Demo perbandingan pola ciphertext ECB dan GCM
- Demo penolakan data ketika authentication tag tidak valid

## Struktur proyek

```text
kriptografi-aes-gcm/
├── src/
│   ├── aesgcm_lab.py
│   └── cli.py
├── test/
│   └── aes_gcm_demo.py
├── requirements.txt
└── README.md
```

## Persiapan

Jalankan perintah dari folder proyek:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

Jika PowerShell menolak aktivasi virtual environment, Anda tetap dapat
menjalankan Python dari `.venv\Scripts\python.exe`.

## Menjalankan demo

```powershell
python -m src.cli demo
python -m src.cli ecb-demo
python -m src.cli file-demo
```

Demo AES-GCM sederhana tambahan:

```powershell
python -m test.aes_gcm_demo
```

## Enkripsi dan dekripsi berkas

Buat kunci AES-256, lalu gunakan kunci yang sama untuk enkripsi dan dekripsi:

```powershell
python -m src.cli keygen --out rahasia.key
python -m src.cli encrypt-file --key rahasia.key --in catatan.txt --out catatan.vgcm
python -m src.cli decrypt-file --key rahasia.key --in catatan.vgcm --out hasil.txt
```

Format berkas terenkripsi terdiri dari penanda `VGCM1` (5 byte), nonce (12
byte), ciphertext, dan authentication tag (16 byte). Dekripsi ditolak jika
autentikasi gagal.

## Catatan keamanan

- Simpan kunci dengan aman. Jangan mengunggah atau meng-commit berkas kunci
  (`*.key`) maupun berkas sensitif yang terenkripsi.
- Jangan pernah menggunakan ulang nonce dengan kunci yang sama.
- ECB hanya digunakan untuk demonstrasi pola dan tidak untuk melindungi data.
- Proyek ini untuk pembelajaran, bukan penggunaan produksi.
