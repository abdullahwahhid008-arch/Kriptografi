
import os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def main():
    key = AESGCM.generate_key(bit_length=256)
    aesgcm = AESGCM(key)

    plaintext = "Praktikum Kriptografi AES-GCM"
    data = plaintext.encode("utf-8")

    nonce = os.urandom(12)
    ciphertext_tag = aesgcm.encrypt(nonce, data, None)

    ciphertext = ciphertext_tag[:-16]
    tag = ciphertext_tag[-16:]

    decrypted = aesgcm.decrypt(nonce, ciphertext_tag, None)
    hasil = decrypted.decode("utf-8")

    print("=== DEMONSTRASI AES-256-GCM ===")
    print("Plaintext       :", plaintext)
    print("Nonce (hex)     :", nonce.hex())
    print("Ciphertext (hex):", ciphertext.hex())
    print("Tag (hex)       :", tag.hex())
    print("Hasil dekripsi  :", hasil)
    print("VERIFIKASI      :", "BERHASIL" if hasil == plaintext else "GAGAL")


if __name__ == "__main__":
    main()
